import java.util.*; 
  
class pro2 
{ 
    public static void main(String[]args) 
    { 
        HashSet<String> h = new HashSet<String>(); 
  
      
        h.add("ram"); 
        h.add("shyam"); 
        h.add("hariiipriya"); 
        h.add("sakhsi");
  
       // System.out.println(h); 
   
        // Iterating over hash set items 
        System.out.println("name of the employee are:"); 
        Iterator<String> i = h.iterator(); 
        while (i.hasNext()) 
            System.out.println(i.next()); 
    } 
} 