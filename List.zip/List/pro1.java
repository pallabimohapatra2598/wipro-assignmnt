import java.io.*; 
import java.util.ArrayList; 
  
public class pro1{ 
    public static void main(String args[]) 
    { 
  
        
        ArrayList<String> arrlist1 =  
                           new ArrayList<String>(12); 
  

        arrlist1.add("january"); 
        arrlist1.add("february"); 
        arrlist1.add("march"); 
	arrlist1.add("april"); 
	arrlist1.add("may"); 
	arrlist1.add("june"); 
	arrlist1.add("july"); 
	arrlist1.add("august"); 
	arrlist1.add("september"); 
	arrlist1.add("october"); 
	arrlist1.add("november"); 
	arrlist1.add("december"); 
 

  
        
        System.out.println("Printing months as a list:"); 
        for (String mnth : arrlist1)  
            System.out.println("months = " + mnth);  
}
}       
  