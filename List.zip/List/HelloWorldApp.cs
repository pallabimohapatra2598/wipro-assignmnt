import java.util.*; 

public class pro5 
{ 
	public static void main(String args[]) 
	{ 
		// Creating object of class linked list 
		LinkedList<String> ll = new LinkedList<String>(); 

		// Adding elements to the linked list 
		ll.add("january"); 
		ll.add("february"); 
		ll.addLast("march"); 
		ll.add("april"); 
		ll.add("may"); 
		ll.add("june"); 
		ll.add("july"); 
		ll.add("august");
		ll.add("september");
		ll.add("october");
		ll.add("november");
		ll.add("december");
		System.out.println("Linked list : " + ll); 

		
	} 
} 
