import java.util.*; 
 public class pro6 { 
    public static void main(String[] arg) 
    { 
  
        
        Vector v = new Vector(); 
  
       		v.add("january"); 
		v.add("february"); 
		v.add("march"); 
		v.add("april"); 
		v.add("may"); 
		v.add("june"); 
		v.add("july"); 
		v.add("august");
		v.add("september");
		v.add("october");
		v.add("november");
		v.add("december"); 
  
        System.out.println("Vector is " + v); 
    } 
}