import java.util.ArrayList;

class Student {
	private int rollNo;
	private String name;
	private float mark;
	
	Student(int rollNo, String name, float mark) {
		this.rollNo = rollNo;
		this.name = name;
		this.mark = mark;
	}
	
	float getMark() {
		return mark;
	}
}

public class Assignment03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Student> list = new ArrayList<>();
		list.add(new Student(101, "hoseok", 85));
		list.add(new Student(102, "jimin", 80));
		list.add(new Student(103, "seojoon", 40));
		list.add(new Student(104, "soohyun", 95));
		list.add(new Student(105, "changwook", 49));
		long count = list.stream().filter(s -> s.getMark() >= 50).count();
		System.out.println(count);
	}

}