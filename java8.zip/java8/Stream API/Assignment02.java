import java.util.ArrayList;
import java.util.stream.Collectors;

class Employee {
	private int empNo;
	private String name;
	private int age;
	private String location;
	
	Employee(int empNo,String name, int age, String location) {
		this.empNo = empNo;
		this.name = name;
		this.age = age;
		this.location = location;
	}
	
	String getLocation() {
		return location;
	}
	
	public String toString(){
		return "Employee No: "+empNo+" name = "+name+" age = "+age+" location = "+location;
	}
}

public class Assignment02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Employee> list = new ArrayList<>();
		list.add(new Employee(101, "namjoon",35,"seoul"));
		list.add(new Employee(102, "seokjin", 40, "gangnam"));
		list.add(new Employee(103, "yoongi", 30, "iteawon"));
		list.add(new Employee(104, "taehyung", 25, "riverhan"));
		list.add(new Employee(105, "jungkook", 29, "namsantower"));
		
		ArrayList res = (ArrayList) list.stream().filter(e -> e.getLocation().equalsIgnoreCase("Pune")).collect(Collectors.toList());
		res.forEach(emp -> System.out.println(emp));
	}

}