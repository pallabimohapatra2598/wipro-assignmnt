import java.util.*;
class employee{
int id;
String name;
String add;
int sal;

public employee(int id,String name,String add,int sal)
{
	this.id=id;
	this.name=name;
	this.add=add;
	this.sal=sal;

}
}
public class foreachpro2{

	
public static void main(String args[]){
ArrayList<employee> li=new ArrayList<>();

li.add(new employee(100,"pall","gajpatinagar1",90000));
li.add(new employee(101,"v","gajpatinagar2",80000));
li.add( new employee(102,"jk","gajpatinagar3",70000));
li.add(new employee(103,"jin","gajpatinagar4",60000));
li.add(new employee(104,"rm","gajpatinagar5",50000));
Iterator<employee> it = li.iterator();
for(employee s : li) //Iterates as long as there are elements in the list. An object s is created of type Employee class.
        {
            System.out.print("ID, Name, City and sal of the employee are : ");
            System.out.println(s.id+" "+s.name+" " +s.add+" "+s.sal);
        }
	  	
}
}