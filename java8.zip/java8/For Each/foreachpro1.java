import java.util.*;
public class foreachpro1{
public static void main(String args[]){
ArrayList<String> li=new ArrayList<String>();
li.add("monday");
li.add("tuesday");
li.add("wednesday");
li.add("thursday");
li.add("friday");
li.add("saturday");
li.add("sunday");
System.out.println("weekdays are:");
li.forEach(n->{
	    System.out.println(n);
});
}
}