import java.util.*;
public class lambda2{
public static void main(String args[]){
ArrayList<String> li=new ArrayList<String>();
li.add("kpop");
li.add("kdrama");
li.add("kim namjoon");
li.add("kim seokjin");
li.add("min yoongi");
li.add("jeon hoesok");
li.add("park jimin");
li.add("kim taehyung");
li.add("jeon jungkook");
li.add("bts");
System.out.println("reversing elements of arraylist:");
li.forEach(n->{
	StringBuffer sb=new StringBuffer(n);
	    System.out.println(sb.reverse().toString());
	  	

});
}
}