import java.util.*;
public class lambda1{
public static void main(String args[]){
ArrayList<Integer> li=new ArrayList<Integer>();
li.add(23);
li.add(15);
li.add(6);
li.add(78);
li.add(3);
li.add(7);
li.add(17);
li.add(27);
li.add(74);
li.add(67);
li.add(37);
li.add(25);
li.add(40);
li.add(10);
li.add(1);
li.add(2);
li.add(45);
li.add(89);
li.add(69);
li.add(56);
li.add(15);
li.add(18);
li.add(90);
li.add(22);
li.add(100);
System.out.println("all prime numbers are:");
li.forEach(n->{
	int flag = 0;
int i;
        for( i = 2; i <= n/2; i++)
        {
            // condition for nonprime number
            if(n % i == 0)
            {
                flag++;
                break;
            }
        }
	  if (flag>=1)
	  {
	     //Appended the Prime number to the String
	    System.out.println(n);
	  }	

});
}
}